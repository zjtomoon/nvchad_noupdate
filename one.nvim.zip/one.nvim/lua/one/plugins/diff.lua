return { 'diff', requires = { 'chrisbra/vim-diff-enhanced' } }
