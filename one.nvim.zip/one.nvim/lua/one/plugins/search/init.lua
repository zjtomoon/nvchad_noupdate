local M = {
	'search',

	deps = {
		require('one.plugins.search.hlslens'),
		require('one.plugins.search.ctrlsf'),
		require('one.plugins.search.visualstar'),
	},
}

return M
