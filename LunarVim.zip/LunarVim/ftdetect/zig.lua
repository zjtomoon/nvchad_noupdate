vim.cmd [[
  au BufRead,BufNewFile *.zir set filetype=zir
]]
