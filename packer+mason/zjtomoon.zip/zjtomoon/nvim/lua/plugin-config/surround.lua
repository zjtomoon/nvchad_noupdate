require"surround".setup {
  mappings_style = "surround"
}
