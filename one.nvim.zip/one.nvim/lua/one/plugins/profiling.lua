return {
	'profiling',
	desc = 'Profiling tools',
	requires = { --
		{ 'dstein64/vim-startuptime', desc = 'Launch vim-startuptime with :StartupTime' },
	},
}
