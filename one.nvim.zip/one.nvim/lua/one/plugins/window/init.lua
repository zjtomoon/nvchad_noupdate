return {
	'window',

	deps = {
		require('one.plugins.window.dim'),
		require('one.plugins.window.resize'),
		require('one.plugins.window.maximize'),
	},
}
