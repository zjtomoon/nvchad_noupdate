# NOTE

## Lua 5.1

neovim 0.8 use LuaJIT 2.1.0-beta3, which full support Lua 5.1, optional support Lua 5.2 and 5.3.

Refer to https://neovim.io/doc/user/lua.html#lua-intro

Read https://github.com/nanotee/nvim-lua-guide to learn nvim and lua.

## table.unpack

This project will set `table.unpack = unpack`.
