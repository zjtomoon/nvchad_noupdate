 require('bufdel').setup({ next = 'tabs', quit = false })
