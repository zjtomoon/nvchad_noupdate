vim.g.tokyonight_style = "storm"
vim.g.tokyonight_enable_italic = false

vim.cmd("set termguicolors")
vim.cmd("colorscheme tokyonight")
