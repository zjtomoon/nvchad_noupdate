vim.g.vista_sidebar_width = 40
