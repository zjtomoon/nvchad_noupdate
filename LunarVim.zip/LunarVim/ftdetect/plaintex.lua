vim.cmd [[ au BufRead,BufNewFile *.tex set filetype=tex ]]
