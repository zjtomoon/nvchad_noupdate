return {
	'hrsh7th/cmp-copilot',
	disable = true,
	requires = {
		{ 'github/copilot.vim' }, -- ":h copilot" how to setup copilot client
	},
}
