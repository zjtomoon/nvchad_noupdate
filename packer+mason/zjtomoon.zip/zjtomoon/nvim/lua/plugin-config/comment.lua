require('Comment').setup(require('keybindings').comment)
