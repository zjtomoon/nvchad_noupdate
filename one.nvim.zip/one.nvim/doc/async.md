# async/await in lua

async lib: [../lua/one/async.lua](../lua/one/async.lua)

Read this [document](https://github.com/ms-jpq/lua-async-await). Thanks to ms-jpq.
