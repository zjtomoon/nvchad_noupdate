return {
    on_setup = function(server)
        server:setup({})
    end,
}
