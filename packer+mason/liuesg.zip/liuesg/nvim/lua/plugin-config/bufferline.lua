require("bufferline").setup({ options = { mode = "tabs" } })
