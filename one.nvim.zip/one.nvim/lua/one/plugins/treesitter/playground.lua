return {
	'nvim-treesitter/playground',
	desc = ':TSPlaygroundToggle and :TSHighlightCapturesUnderCursor',
	keymaps = { { 'n', '<leader>h', ':TSHighlightCapturesUnderCursor<CR>' } },
}
