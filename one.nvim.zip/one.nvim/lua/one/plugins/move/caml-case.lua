return {
	'bkad/CamelCaseMotion',
	keymaps = {
		{ '', 'w', '<Plug>CamelCaseMotion_w', { silent = true } },
		{ '', 'b', '<Plug>CamelCaseMotion_b', { silent = true } },
		{ '', 'e', '<Plug>CamelCaseMotion_e', { silent = true } },
		{ '', 'W', 'w', { noremap = true } },
		{ '', 'B', 'b', { noremap = true } },
		{ '', 'E', 'e', { noremap = true } },
	},
}
