# Neovim config

This is my neovim config.

Dependencies:
```bash
sudo apt install curl ripgrep
```

To install packer, do:
```bash
git clone --depth 1 https://github.com/wbthomason/packer.nvim ~/.local/share/nvim/site/pack/packer/start/packer.nvim
```
