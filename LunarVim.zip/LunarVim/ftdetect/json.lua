vim.cmd [[
 au BufRead,BufNewFile tsconfig.json set filetype=jsonc
]]
